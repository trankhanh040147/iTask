package constant

const (
	MomoStatusOK = 0
)

const (
	RedirectURLMomo = "http://localhost:3000/reservations/"
)
