package constant

const (
	URL_HOST_EC2 = "http://54.255.194.221:8080/api/v1"
)
