package constant

const (
	LocationType_Rooftop           = "ROOFTOP"
	LocationType_RangeInterpolated = "RANGE_INTERPOLATED"
	LocationType_GeometricCenter   = "GEOMETRIC_CENTER"
	LocationType_Approximate       = "APPROXIMATE"
)

// trigger cicd