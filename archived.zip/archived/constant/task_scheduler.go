package constant

const (
	TaskUpdateStatusBooking = "task:update_status_booking"
)
