package constant

const (
	LengthRandomCode       = 8
	ExpiredTimeVerifyEmail = 5 // minutes
)
