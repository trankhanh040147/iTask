package iomodel

type AccountChangeRole struct {
	Role int `json:"role"`
}
