package amenityhandler

import (
	"github.com/gin-gonic/gin"
)

func (hdl *amenityHandler) ListAllAmenityConfig() gin.HandlerFunc {
	return func(c *gin.Context) {

	}
}
