package iomodel

type ListPlaceReq struct {
	UserEmail string `json:"user_email" form:"user_email"`
}
